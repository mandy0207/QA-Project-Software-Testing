import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class EndToEndFlightSearching {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "c:\\work\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://spicejet.com/");
		Thread.sleep(2000L);

		driver.findElement(By.id("ctl00_mainContent_ddl_originStation1_CTXT")).click();

		driver.findElement(By.xpath("//a[@value='DEL']")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//div[@id='glsctl00_mainContent_ddl_destinationStation1_CTNR'] //a[@value='MAA']"))
				.click();

		driver.findElement(By.cssSelector(".ui-state-default.ui-state-highlight.ui-state-active")).click();

		driver.findElement(By.id("divpaxinfo")).click();

		Thread.sleep(2000L);
		WebElement staticDropdown = driver.findElement(By.id("ctl00_mainContent_ddl_Adult"));
		Select dropdown = new Select(staticDropdown);
		dropdown.selectByIndex(3);

		WebElement staticDropdown2 = driver.findElement(By.id("ctl00_mainContent_DropDownListCurrency"));
		Select dropdown2 = new Select(staticDropdown2);
		dropdown2.selectByValue("AED");

		driver.findElement(By.cssSelector("input[id*='SeniorCitizenDiscount']")).click();

		driver.findElement(By.cssSelector("input[value='Search']")).click();
		Thread.sleep(2000L);
		driver.findElement(By.xpath("//a[@id='ControlGroupSelectView_AvailabilityInputSelectView_GoingNextday']")).click();
	}

}
