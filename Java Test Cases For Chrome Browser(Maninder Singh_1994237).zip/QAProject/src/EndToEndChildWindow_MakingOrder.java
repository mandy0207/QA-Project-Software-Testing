
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class EndToEndChildWindow_MakingOrder {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "c:\\work\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://spicejet.com/");
		Thread.sleep(2000L);
		driver.findElement(By.id("spicestyleheader")).click();
		Thread.sleep(2000L);
		
		
		Set <String> windowIds=driver.getWindowHandles();
		Iterator<String> iter=windowIds.iterator();
		String mainWindow=iter.next();
		String childWindow=iter.next();
		driver.switchTo().window(childWindow);
		Thread.sleep(2000L);
		WebElement Men=driver.findElement(By.xpath("//div[@class='uiv2-main-menu']/nav/ul/li[5]"));
		Actions act=new Actions(driver);
		act.moveToElement(Men).build().perform();
		act.moveToElement(Men).sendKeys(Keys.DOWN).build().perform();
		act.moveToElement(Men).click().build().perform();
		Thread.sleep(2000L);
		
		driver.findElement(By.xpath("//a[contains(text(),'Price: Low to High')]")).click();
		Thread.sleep(2000L);
		
		driver.findElement(By.xpath("//body[1]/div[5]/div[2]/div[1]/div[1]/div[5]/div[1]/div[2]/div[4]/div[1]/div[1]/a[1]")).click();
		Thread.sleep(2000L);
		driver.findElement(By.xpath("//a[contains(text(),'BUY NOW')]")).click();
		Thread.sleep(2000L);
		driver.findElement(By.id("guest_name")).sendKeys("Maninder Singh");
		driver.findElement(By.id("mobile_number")).sendKeys("9988215943");
		driver.findElement(By.id("pincode")).sendKeys("143521");
		driver.findElement(By.id("address")).sendKeys("Nanak Sahai Colony Opp. Mohan Plaza Palace");
		driver.findElement(By.id("city")).sendKeys("Gurdaspur");
		driver.findElement(By.id("guest_register")).sendKeys("mandyatwork24@gmail.com");
		driver.findElement(By.id("locality")).sendKeys("Near Bajwa Hospital");
		driver.findElement(By.id("otp")).sendKeys("12345");
		driver.findElement(By.id("signup")).click();
		System.out.println("OTP Doesnot Match");
		System.out.println("Test Ended Successfully");
		
		
		
		
	//System.out.println(driver.getTitle());
	
		
		
	}

}
