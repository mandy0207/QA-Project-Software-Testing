
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class QAProject {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "c:\\work\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://spicejet.com/");
		driver.findElement(By.id("divpaxinfo")).click();

		Thread.sleep(2000L);
		WebElement staticDropdown = driver.findElement(By.id("ctl00_mainContent_ddl_Adult"));
		Select dropdown = new Select(staticDropdown);
		dropdown.selectByIndex(3);
		// System.out.println(dropdown.getFirstSelectedOption().getText());
		System.out.println(driver.findElement(By.id("divpaxinfo")).getText());
	}
}
