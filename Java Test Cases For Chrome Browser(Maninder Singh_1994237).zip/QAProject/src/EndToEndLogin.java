

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class EndToEndLogin {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "c:\\work\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://spicejet.com/");
		Thread.sleep(2000L);
		WebElement Login=driver.findElement(By.xpath("(//a[text()='Login / Signup'])[1]"));
		
		//Action class is used to perform Mouse Operations
		Actions act=new Actions(driver);
		act.moveToElement(Login).build().perform();
		
		WebElement SpiceClubMembers=driver.findElement(By.xpath("//a[text()='SpiceClub Members']"));
		act.moveToElement(SpiceClubMembers).build().perform();
		
		WebElement MemberLogin=driver.findElement(By.xpath("(//a[text()='Member Login'])[2]"));
		act.moveToElement(MemberLogin).click().build().perform();
		Thread.sleep(2000L);
		driver.findElement(By.cssSelector("input[id*='TextBoxUserID']")).sendKeys("9988215943");
		driver.findElement(By.cssSelector("input[id*='PasswordFieldPassword']")).sendKeys("12345678");
		driver.findElement(By.cssSelector("input[id*='ButtonLogIn']")).click();
		
		
	}
}
