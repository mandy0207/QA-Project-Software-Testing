import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class EndToEndSignup {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "c:\\work\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://spicejet.com/");
		Thread.sleep(2000L);
		WebElement Signup = driver.findElement(By.xpath("(//a[text()='Login / Signup'])[1]"));

		// Action class is used to perform Mouse Operations
		Actions act = new Actions(driver);
		act.moveToElement(Signup).build().perform();

		WebElement SpiceClubMembers = driver.findElement(By.xpath("//a[text()='SpiceClub Members']"));
		act.moveToElement(SpiceClubMembers).build().perform();
		WebElement MemberLogin = driver.findElement(By.xpath("(//a[text()='Member Login'])[2]"));
		// WebElement MemberLogin=driver.findElement(By.xpath("//a[contains(text(),'Sign
		// up')]"));
		act.moveToElement(MemberLogin).sendKeys(Keys.DOWN).build().perform();
		act.moveToElement(MemberLogin).click().build().perform();
		Thread.sleep(4000L);

		WebElement staticDropdown = driver
				.findElement(By.cssSelector("#CONTROLGROUPREGISTERVIEW_PersonInputRegisterView_DropDownListTitle"));
		Select dropdown = new Select(staticDropdown);
		dropdown.selectByValue("MR");

		driver.findElement(By.cssSelector("input[id*='TextBoxFirstName']")).sendKeys("Mandy");
		driver.findElement(By.cssSelector("input[id*='TextBoxLastName']")).sendKeys("Taak");
		driver.findElement(By.cssSelector("input[id*='TEXTBOXINTLMOBILENUMBER']")).sendKeys("9988215943");
		driver.findElement(By.cssSelector("input[id*='PasswordFieldAgentPassword']")).sendKeys("12345678#q");
		driver.findElement(By.cssSelector("input[id*='PasswordFieldPasswordConfirm']")).sendKeys("12345678#q");
		driver.findElement(By.cssSelector("input[id*='TextBoxEmail']")).sendKeys("Manyatwork24@gmail.com");
		driver.findElement(By.cssSelector("input[id*='TEXTBOXINPUTDOB']")).click();
		driver.findElement(By.xpath(".//span[contains(text(),'1996 - 2007')]")).click();
		driver.findElement(
				By.xpath("//div[@class='datepickerContainer']/table/tbody/tr/td/table/tbody[2]//tr[2]/td[2]")).click();

		driver.findElement(By.id("chkSpiceClubTnC")).click();
		driver.findElement(By.cssSelector("input[id*='ButtonSubmit']")).click();
		Thread.sleep(2000L);
		driver.findElement(By.cssSelector("input[id*='TextBoxOtp']")).sendKeys("1234");
		driver.findElement(By.id("btnValidateOTPTel")).click();

	}

}
